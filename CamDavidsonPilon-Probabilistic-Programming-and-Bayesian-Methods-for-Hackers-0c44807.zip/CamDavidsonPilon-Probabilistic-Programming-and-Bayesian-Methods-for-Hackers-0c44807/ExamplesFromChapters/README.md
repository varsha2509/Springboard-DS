## Read Me


Included is all PyMC examples and models *out of context*, this is for users to easily view the entire Python program. 

